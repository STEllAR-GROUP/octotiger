#!/bin/bash -e
set -x

if [ ! -d "octotiger/" ]; then
    git clone https://github.com/STEllAR-GROUP/octotiger.git
else
    cd octotiger
    git pull
    cd ..
fi

cd octotiger
git checkout double_loop_comp_int
cd ..

mkdir -p octotiger/build
cd octotiger/build
# add -DBOOST_ROOT="$Boost_ROOT", if boost is not in system paths
cmake -DBOOST_ROOT=${BOOST_ROOT}  -DOCTOTIGER_WITH_SILO=OFF -DCMAKE_PREFIX_PATH="$HPX_ROOT" -DCMAKE_BUILD_TYPE=release -DCMAKE_CXX_FLAGS="-march=native" -DHPX_IGNORE_COMPILER_COMPATIBILITY=ON ../
make -j ${BUILD_THREADS} VERBOSE=1
cd ../..
