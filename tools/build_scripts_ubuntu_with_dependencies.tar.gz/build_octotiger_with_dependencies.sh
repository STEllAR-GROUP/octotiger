#/bin/bash
set -x

export Vc_ROOT=/home/pfandedd/my_build_dir/Vc_install
export HPX_ROOT=/home/pfandedd/my_build_dir/hpx_install
# if you want to use a different version of boost, you have to change the boost build script
export BOOST_ROOT=/home/pfandedd/my_build_dir/boost_1_62_0_install/
export BUILD_THREADS=8

# also requires boost, binutils, gcc
sudo apt-get install -y cmake libjemalloc-dev libhwloc-dev

./scripts/build-boost.sh
./scripts/build-Vc.sh
./scripts/build-hpx.sh
./scripts/build-octotiger.sh
